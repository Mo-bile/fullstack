package test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

public class test {

	public static void main (String[] args) throws IOException {
		
		int kor1 = 0, kor2 = 0 , kor3 = 0;
		
//		파일 성적 입력
		{
		//파일 읽어오고 응용하기
		//읽어온 문자열 배열화
		FileInputStream fis = new FileInputStream("res/data.csv");
		Scanner scan = new Scanner(fis);
			
		
		//배열값 각자 입력
		String line = scan.nextLine();
		String[] kors = line.split(",");
		
		for(int i = 0 ; i < kors.length ; i++) {
			kor1 = Integer.parseInt(kors[i]);
			kor2 = Integer.parseInt(kors[i]);
			kor3 = Integer.parseInt(kors[i]);
		}
		
		
		//닫아주기
		scan.close();
		fis.close();
		
		}
		
		
//		파일 성적 출력
		{
		
		//파일 들고오고, 응용하기
		FileOutputStream fos = new FileOutputStream("res/data.txt");
		PrintStream out = new PrintStream(fos);
			
		//파일에다가 입력하기
		out.printf("값은 3 : %d,%d%d", kor1,kor2,kor3);
		
		//닫고 알리기
		out.close();
		fos.close();
		
		
		
		
		}
	}

}
