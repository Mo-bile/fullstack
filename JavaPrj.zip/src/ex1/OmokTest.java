package ex1;

public class OmokTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		{
			System.out.printf("%c", '┌');
			for(int i = 0 ; i < 10 ; i++)
				System.out.printf("%c", '┬');
			System.out.printf("%c", '┐');
			
			System.out.println();
		}
			
			
		for(int y = 1 ; y <= 10 ; y++) {
			System.out.printf("%c", '├');
			for(int x = 1 ; x <= 10 ; x++) 		//문장하나는 굳이 괄호를 쓰지 않는다.
						if(x == 3 && y == 3) 
							System.out.printf("%c", '○');				
						else
							System.out.printf("%c", '┼');
									
			
			System.out.printf("%c", '┤');
			System.out.println();
		}
		
		
		
		{
			System.out.printf("%c", '└');
			for(int i = 0 ; i < 10 ; i++)
				System.out.printf("%c", '┴');
			System.out.printf("%c", '┘');
		}
			
//		-----------------------------------
		
		
		System.out.println("\n\n\n\n\n");
		
		for(int i = 0 ; i < 100 ; i++) { 
			
			if(i == 22)
				System.out.printf("%c", '○');
			else 	
				System.out.printf("%c", '┼');
			
			
			if((i + 1) % 10 == 0) // 괄호로 우선순위 생각을 하지 못했음
				System.out.print("\n");
			
		}
		
	}

}
