package ex1;

public class ForTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i = 0 ; i < 5 ; i++) {
			
			if(i < 2)
				continue;
			
			System.out.print("☆");
			System.out.printf("%d", i+1);
				
			if(i != 4)  // i != 4
				System.out.print(",");
				
			
			}
		
		
		
		
		}
	}
