package ex1;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
			for(int i = 0 ; i < 10 ; i++) {
				
				if(i == 5)
					System.out.printf("%c", '○');
				
				else if(i % 2 == 1)
					System.out.printf("%c", '★');
				
				else { //기본출력으로 두기 (기본값)			
					System.out.printf("%c", '┼');
				}
			}
			
			System.out.println("\n\n switch 경우 ");
			
			for(int i = 0 ; i < 10 ; i++) {
				
				switch (i) {
				case 4 : 
					System.out.printf("%c", '○');
					continue;
				case 5:
					System.out.printf("%c", '★');
					continue;			
				default :
					System.out.printf("%c", '┼');
					
				}}
		
	
}}
