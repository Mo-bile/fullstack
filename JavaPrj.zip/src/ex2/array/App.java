package ex2.array;


//저작자 : 모
//저작일자 : 2022-12-06

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

public class App{
	
	public static void main (String[] args) throws IOException {
		
		
		int[] kors = new int[3]; 
		//여러개라는 방의 의미는 korList나 kors가 바람직함
		
		for(int i = 0 ; i < 3 ; i++)
			kors[i] = 0;
		
		int answer = 1; //
		
		
		NEWLEC: //브레이크 라벨
		while(answer == 1) {
		
			int menu;

			{
			Scanner scan = new Scanner(System.in);
			
			
			System.out.println("┌──────────┐"); 
			System.out.println("│                       │");
			System.out.println("│        메뉴 입력        │");
			System.out.println("│                       │");
			System.out.println("└──────────┘");
			
			System.out.println("1. 콘솔 성적 입력");
			System.out.println("2. 콘솔 성적 출력");
			System.out.println("3. 파일 성적 입력");
			System.out.println("4. 파일 성적 출력");
			System.out.println("5. 종료");
			System.out.print(">");
			
			menu = scan.nextInt();
			}
			
			switch(menu) {
			
			case 1:
				{ //1. 콘솔 성적 입력
	
	//				콘솔입력블럭
					Scanner scan = new Scanner(System.in);
					
	//				화면출력단 --------------------------------
					System.out.println("┌─────────┐"); 
					System.out.println("│                       │");
					System.out.println("│        성적 입력        │");
					System.out.println("│                       │");
					System.out.println("└─────────┘");
					
					
					for(int i = 0 ; i < 3 ; i++)  //한문장으로서 블럭잡을필요없음
											
						do {
							System.out.printf("국어%d:", i + 1);
							kors[i] = scan.nextInt();
							
							if(kors[i] < 0 || kors[i] > 100 )
								System.out.println("점수를 100까지만 입력해야합니다 \n 다시 입력해주세요");
							}
							while(kors[i] < 0 ||kors[i] > 100);
									
						}
				break;
			case 2 :
				{ //2. 콘솔 성적 출력
					//아래는 콘솔출력부분임
					{
				
					System.out.println("┌─────────┐"); 
					System.out.println("│                            │");
					System.out.println("│        성적 출력      │");
					System.out.println("│                            │");
					System.out.println("└─────────┘");
					
					for(int j = 0 ; j < 3 ; j ++) {
						
						int total = 0 ; //매번 초기화 되게끔
						System.out.printf("-----------<%d>-----------\n", j + 1 ); 
						
						for(int i = 0 ; i < 3 ; i++)
							total += kors[i];
						
						double avg = total / 3.0; 
						
						for(int i = 0 ; i < 3 ; i++){ //for문안은 가급적 바꾸지 않는것이 바람직 
						System.out.printf("국어%d : %5d\n", i+1 ,kors[i]);
						System.out.printf("총점 : %5d\n", total);
						System.out.printf("평균 : %6.2f\n", avg);
						}           
							
				}
					
					}
				}
				break;
			case 3 :
				{ //3. 파일 성적 입력
	//				파일 입력블록
					{
						
						
						FileInputStream fis = new FileInputStream("res/data.csv"); //버퍼를 마련함
						Scanner scan = new Scanner(fis); // scan 이름 중복된다. 이경우 벽을 만드는 '지역화'가 가능 함
						
						String line = scan.nextLine(); 
						String[] tokens = line.split(","); 
						//변수명을 ,를 기준으로 나누기 때문에 token 혹은 tmp 를쓴다.
						
						//그냥 kor1 에 두면 정수형이라서 에러발생한다.
						for(int i = 0 ; i < 3 ; i++)
							kors[i] = Integer.parseInt(tokens[i]); //90
						
						
						scan.close(); //얘는 수동으로 닫아주어야 > 내가 만들어서
						fis.close(); // 다른거 하기전에 1순위로 가장 먼저 해보기
				
						}
				}
				break;
				
			case 4:
				{ //4. 파일 성적 출력
					{
					FileOutputStream fos = new FileOutputStream("res/data.txt");
					PrintStream out = new PrintStream(fos); //위 fos를 응용하는 객체가 만들어짐
					
						for(int i = 0 ; i < 3 ; i++) {
							out.printf("%d", kors[i]);	
							if(i == 2)
								out.print("\n");	
							else
								out.print(",");
						}
					fos.close();
					
					System.out.println("작업관료 ");
					}
					
				
				}
				break;
				
			case 5:
				{ //5. 종료
					System.out.println("프로그램을 종료합니다.");
					break;
				}
				
			default : 
					{
					System.out.println("1~5만 입력가능함");
					System.out.println("치명적인 오류로 프로그램을 종료합니다.");
					break NEWLEC;
				}
			}
			
			
		//파일저장 블록	
		
		{
//		반복문 중지 관련 단
		
		
		//사용자에게 계속할지 유무를 answer에 입력 받는다.
		//계속하시겠습니까 계속1 / 종료 0
		System.out.println("계속하시겠습니다? (계속:1 / 종료 :0)");
		Scanner scan = new Scanner(System.in);
		
		answer = scan.nextInt();
		
		}	
		
		
	}for(int i = 0 ; i < 5 ; i++) {
		System.out.printf("Bye Bye my blue %d \n", i+1);
		try {
			Thread.sleep(500); // 0.5초씩 딜레이 주기
		}catch(Exception e) { //예외처리
			System.out.println(e); 
		}
		
	}}}

