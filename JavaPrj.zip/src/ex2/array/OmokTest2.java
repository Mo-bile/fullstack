package ex2.array;

public class OmokTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

			
		for(int y = 1 ; y <= 10 ; y++) {
			for(int x = 1 ; x <= 10 ; x++) 		//문장하나는 굳이 괄호를 쓰지 않는다.
						if(x == 3 && y == 3) 
							System.out.printf("%c", '○');		
			
						else if(x == 1 && y == 1)
							System.out.printf("%c", '┌');
						else if(x == 1 && y == 10)
							System.out.printf("%c", '└');
						else if(x == 10 && y == 1)
							System.out.printf("%c", '┐');
						else if(x == 10 && y == 10)
							System.out.printf("%c", '┘');
			
						else if( x == 1)
							System.out.printf("%c", '├');
						else if( y == 1)
							System.out.printf("%c", '┬');
						else if( y == 10 )
							System.out.printf("%c", '┴');
						else if( x== 10 )
							System.out.printf("%c", '┤');
			
			
						else
							System.out.printf("%c", '┼');
									
			
			System.out.println();
		}
	}

}
