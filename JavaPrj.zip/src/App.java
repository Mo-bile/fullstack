public class App {
	public static void main(String[] args) {

		int kor1 = 60;
		int kor2 = 80;
		int kor3 = 90;

		int total = kor1 + kor2 + kor3;
		float avg = total / 3;
	
		System.out.println("total is " + total);
		System.out.printf("avg is %f", avg);
		
		char x = 'A';
		int y = 1;
		
		System.out.println("\n\nx "+x);
		System.out.println("\ny "+y);
	}
}