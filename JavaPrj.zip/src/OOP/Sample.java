package OOP;

class Animal{
	
	String name;
	
	public void setName(String name) {
		
		this.name = name;
		
	}
	
	
}


public class Sample {
	
	public static void main (String [] args) {
	
		Animal cat = new Animal();
		Animal cow = new Animal();
		Animal dog = new Animal();
		
		cat.name = "cheese";
		cow.name = "omm";
		dog.name = "bow";
		
		System.out.println(cat.name);
		cat.setName("reCheese");
		System.out.println(cat.name);

	}
}
